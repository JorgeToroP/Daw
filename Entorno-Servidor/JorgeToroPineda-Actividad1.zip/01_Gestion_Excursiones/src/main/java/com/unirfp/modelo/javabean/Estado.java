package com.unirfp.modelo.javabean;

public enum Estado {
	CREADO,CANCELADO,TERMINADO
}
