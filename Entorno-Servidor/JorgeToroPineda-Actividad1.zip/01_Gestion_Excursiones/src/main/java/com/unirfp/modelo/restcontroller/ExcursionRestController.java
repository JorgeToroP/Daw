package com.unirfp.modelo.restcontroller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.unirfp.modelo.dao.ExcursionDao;
import com.unirfp.modelo.javabean.Estado;
import com.unirfp.modelo.javabean.Excursion;

@RestController
public class ExcursionRestController {
	
	private final ExcursionDao excursionDao;

	ExcursionRestController(ExcursionDao excursionDao) {
		this.excursionDao = excursionDao;
	}

	@GetMapping("/")
	public List<Excursion> todos(){
		return excursionDao.findAll();
	}
	
	@GetMapping("/excursion/detalle/{id}")
	public Excursion detalle(@PathVariable int id) {
		return excursionDao.findById(id);
	}
	
	@PutMapping("/excursion/cancelar/{id}")
	public int cancelar(@PathVariable int id){
		 Excursion idCancelar = excursionDao.findById(id);
		 idCancelar.setEstado(Estado.CANCELADO);
		 int filaModificada = excursionDao.updateOne(idCancelar);
		 return filaModificada;
	}
	
	@PutMapping("/excursion/modificar")
	public int modificar(@RequestBody Excursion excursion){
		int modificao = excursionDao.updateOne(excursion);
		return modificao;
	}
	
	
	@GetMapping("/excursion/destacados")
	public List<Excursion> destacado() {
		return excursionDao.findByDestacados();
	}
	@GetMapping("/excursion/creados")
	public List<Excursion> creados(){
		return excursionDao.findByActivos();
	}

	
	@GetMapping("/excursion/terminados")
	public List<Excursion> terminados(){
		
		List<Excursion> todas = excursionDao.findAll();
		List<Excursion> filtro = new ArrayList<>();
		
		for (Excursion excursion: todas) {
			if(excursion.getEstado()==Estado.TERMINADO) {
				filtro.add(excursion);
			}
				
		}
		return filtro;
	}
		
	@PostMapping("/excursion/alta")
	public int alta(@RequestBody Excursion excursion) {
		return excursionDao.insertOne(excursion);
	}
	
}
