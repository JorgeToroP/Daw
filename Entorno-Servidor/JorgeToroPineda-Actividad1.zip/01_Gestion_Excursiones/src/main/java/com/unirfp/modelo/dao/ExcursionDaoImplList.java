package com.unirfp.modelo.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.springframework.stereotype.Repository;
import com.unirfp.modelo.javabean.Estado;
import com.unirfp.modelo.javabean.Excursion;


@Repository
public class ExcursionDaoImplList implements ExcursionDao{


	private List<Excursion> lista;
	
	public ExcursionDaoImplList() {

		lista = new ArrayList<>();
		cargarDatos();

	}
	
	private void cargarDatos() {
		lista.add(new Excursion(1001,"Entre pueblos","Haro","La Bastida",new Date(),180,Estado.CREADO,"S",30,15,20.00,"pueblos.jpg",new Date()));
		lista.add(new Excursion(1002, "Ruta del Vino", "Logroño", "Briones", new Date(), 240, Estado.CREADO, "N", 40, 20, 35.00, "vino.jpg", new Date()));
		lista.add(new Excursion(1003, "Monasterios Suso y Yuso", "Haro", "San Millán", new Date(), 300, Estado.CANCELADO, "S", 25, 10, 25.50, "monasterio.jpg", new Date()));
		lista.add(new Excursion(1004, "Vía Verde del Cidacos", "Arnedo", "Calahorra", new Date(), 120, Estado.TERMINADO, "N", 50, 15, 15.00, "cidacos.jpg", new Date()));
		lista.add(new Excursion(1005, "Senderismo Ezcaray", "Logroño", "Ezcaray", new Date(), 210, Estado.TERMINADO, "S", 35, 12, 30.00, "ezcaray.jpg", new Date()));
	}
	
	
	
	@Override
	public Excursion findById(int idExcursion) {
		
		for(Excursion excursion:lista) {
			if(excursion.getIdExcursion()==idExcursion) 
				return excursion;	 
		}	
		return null;
		/*
		return lista.stream()
				.filter(e -> e.getIdExcursion()
						==(idExcursion))
						.findFirst()
						.orElse(null);
						*/
	}

	@Override
	public List<Excursion> findAll() {
		
		return lista;
	}

	@Override
	public int insertOne(Excursion excursion) {	 
		lista.add(excursion);
		return 1;
		
	}

	
	@Override
	public int updateOne(Excursion excursion) {
		
		for(int i=0; i<lista.size();i++) {
			if(excursion.getIdExcursion()==lista.get(i).getIdExcursion()) {
				 lista.set(i, excursion);
				 return 1;
			}
		}
		return 0;
	}

	
	@Override
	public List<Excursion> findByActivos() {
		
		List<Excursion> filtro = new ArrayList<>();
		
		for(Excursion excursion : lista) {
			if(excursion.getEstado()==Estado.CREADO) {
				filtro.add(excursion);
			}		 
		}
		return filtro;
	}

	@Override
	public List<Excursion> findByCancelados() {
		List<Excursion> filtro = new ArrayList<>();
		for(Excursion excursion :lista) {
			if(excursion.getEstado()==Estado.CANCELADO) {
				filtro.add(excursion);
			}
		}
		return filtro;
	}

	@Override
	public List<Excursion> findByDestacados() {
		List<Excursion> filtro = new ArrayList<>();
		for(Excursion excursion:lista) {
			if(excursion.getDestacado().equals("S")) {
				filtro.add(excursion);
			}
		}
		return filtro;
	}
}
