package com.unirfp.modelo.javabean;

import java.util.Date;
import java.util.Objects;

public class Excursion {
	
	private int idExcursion;
	private String descripcion;
	private String origen;
	private String destino;
	private java.util.Date fechaExcursion;
	private int duracion;
	private Estado estado;
	private String destacado;
	private int aforoMaximo;
	private int minimoAsistentes;
	private double precioUnitario;
	private String imagen;
	private java.util.Date fechaAlta;
	
	
//constructor
	public Excursion(int idExcursion, String descripcion, String origen, String destino, Date fechaExcursion,
			int duracion, Estado estado, String destacado, int aforoMaximo, int minimoAsistentes, double precioUnitario,
			String imagen, Date fechaAlta) {
		super();
		this.idExcursion = idExcursion;
		this.descripcion = descripcion;
		this.origen = origen;
		this.destino = destino;
		this.fechaExcursion = fechaExcursion;
		this.duracion = duracion;
		this.estado = estado;
		this.setDestacado(destacado);
		this.aforoMaximo = aforoMaximo;
		this.minimoAsistentes = minimoAsistentes;
		this.precioUnitario = precioUnitario;
		this.imagen = imagen;
		this.fechaAlta = fechaAlta;
	}
	
	
	//constructor vacio
	public Excursion() {
		super();
	}


	//getters y setters
	public int getIdExcursion() {
		return idExcursion;
	}
	public void setIdExcursion(int idExcursion) {
		this.idExcursion = idExcursion;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getOrigen() {
		return origen;
	}
	public void setOrigen(String origen) {
		this.origen = origen;
	}
	public String getDestino() {
		return destino;
	}
	public void setDestino(String destino) {
		this.destino = destino;
	}
	public java.util.Date getFechaExcursion() {
		return fechaExcursion;
	}
	public void setFechaExcursion(java.util.Date fechaExcursion) {
		this.fechaExcursion = fechaExcursion;
	}
	public int getDuracion() {
		return duracion;
	}
	public void setDuracion(int duracion) {
		this.duracion = duracion;
	}
	public Estado getEstado() {
		return estado;
	}
	public void setEstado(Estado estado) {
		this.estado = estado;
	}
	public String getDestacado() {
		return destacado;
	}
	public void setDestacado(String destacado) {
		destacado = destacado.toUpperCase();
		if(destacado.equals("S")||destacado.equals("N") ) {
			this.destacado = destacado;
		}else {
			throw new IllegalArgumentException("Error: destacado debe ser S o N ");
		}
			
	}
	public int getAforoMaximo() {
		return aforoMaximo;
	}
	public void setAforoMaximo(int aforoMaximo) {
		this.aforoMaximo = aforoMaximo;
	}
	public int getMinimoAsistentes() {
		return minimoAsistentes;
	}
	public void setMinimoAsistentes(int minimoAsistentes) {
		this.minimoAsistentes = minimoAsistentes;
	}
	public double getPrecioUnitario() {
		return precioUnitario;
	}
	public void setPrecioUnitario(double precioUnitario) {
		this.precioUnitario = precioUnitario;
	}
	public String getImagen() {
		return imagen;
	}
	public void setImagen(String imagen) {
		this.imagen = imagen;
	}
	public java.util.Date getFechaAlta() {
		return fechaAlta;
	}
	public void setFechaAlta(java.util.Date fechaAlta) {
		this.fechaAlta = fechaAlta;
	}



	@Override
	public String toString() {
		return "Excursion [idExcursion=" + idExcursion + ", descripcion=" + descripcion + ", origen=" + origen
				+ ", destino=" + destino + ", fechaExcursion=" + fechaExcursion + ", duracion=" + duracion + ", estado="
				+ estado + ", destacado=" + destacado + ", aforoMaximo=" + aforoMaximo + ", minimoAsistentes="
				+ minimoAsistentes + ", precioUnitario=" + precioUnitario + ", imagen=" + imagen + ", fechaAlta="
				+ fechaAlta + "]";
	}



	@Override
	public int hashCode() {
		return Objects.hash(Integer.valueOf(aforoMaximo), descripcion, destacado, destino, Integer.valueOf(duracion),
				estado, fechaAlta, fechaExcursion, Integer.valueOf(idExcursion), imagen,
				Integer.valueOf(minimoAsistentes), origen, Double.valueOf(precioUnitario));
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!(obj instanceof Excursion))
			return false;
		Excursion other = (Excursion) obj;
		return aforoMaximo == other.aforoMaximo && Objects.equals(descripcion, other.descripcion)
				&& Objects.equals(destacado, other.destacado) && Objects.equals(destino, other.destino)
				&& duracion == other.duracion && Objects.equals(estado, other.estado)
				&& Objects.equals(fechaAlta, other.fechaAlta) && Objects.equals(fechaExcursion, other.fechaExcursion)
				&& idExcursion == other.idExcursion && Objects.equals(imagen, other.imagen)
				&& minimoAsistentes == other.minimoAsistentes && Objects.equals(origen, other.origen)
				&& Double.doubleToLongBits(precioUnitario) == Double.doubleToLongBits(other.precioUnitario);
	}
	
	
	
	
	
}
