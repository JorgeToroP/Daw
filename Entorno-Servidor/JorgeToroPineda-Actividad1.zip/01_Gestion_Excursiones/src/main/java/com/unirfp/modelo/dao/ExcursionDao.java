package com.unirfp.modelo.dao;

import java.util.List;

import com.unirfp.modelo.javabean.Excursion;

public interface ExcursionDao {
	
	Excursion findById(int idExcursion);
	
	List<Excursion> findAll();
	
	int insertOne(Excursion excursion);
	int updateOne(Excursion excursion);
	
	List<Excursion> findByActivos();
	List<Excursion> findByCancelados();
	List<Excursion> findByDestacados();
	
}
